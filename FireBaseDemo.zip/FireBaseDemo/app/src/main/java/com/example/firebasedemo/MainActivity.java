package com.example.firebasedemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    EditText editText, enterDesc, editDate;
    String titlesend, descsend, datesend;
    Button addButton;
    ListView listViewNotes;
    DatabaseReference mDatabase;
    List<Notes> notesList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mDatabase = FirebaseDatabase.getInstance().getReference("notes");
        editText = findViewById(R.id.editText);
        enterDesc = findViewById(R.id.enterDesc);
        editDate = findViewById(R.id.editDate);
        SimpleDateFormat dateF = new SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault());
        String date = dateF.format(Calendar.getInstance().getTime());
        editDate.setText(date);
        addButton = findViewById(R.id.addButton);
        listViewNotes =(ListView)findViewById(R.id.listViewNotes);
        notesList = new ArrayList<>();
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddNotes();
                editText.setText("");
                enterDesc.setText("");
               // editDate.setText("");

            }
        });
        listViewNotes.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Notes notes =notesList.get(position);
                showUpdateDialogue(notes.getNotesid(), notes.getNotestitle(), notes.getNotesdesc(), notes.getNotesdate());
                return false;
            }
        });

    }
    @Override
    public void onStart() {
        super.onStart();
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                notesList.clear();
                for (DataSnapshot notesSnapshot : dataSnapshot.getChildren()) {
                    Notes notes = notesSnapshot.getValue(Notes.class);
                    notesList.add(notes);
                }
                NotesList adapter = new NotesList(MainActivity.this, notesList);
                listViewNotes.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    public void showUpdateDialogue(final String notesid, String notestitle, String notesdesc, String notesdate){
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogueView = inflater.inflate(R.layout.update_layout, null);
        alertDialog.setView(dialogueView);
        final EditText titleupdate = (EditText)dialogueView.findViewById(R.id.titleupdate);
        final EditText descupdate = (EditText)dialogueView.findViewById(R.id.descupdate);
        final EditText dateupdate = (EditText)dialogueView.findViewById(R.id.dateupdate);
        SimpleDateFormat dateF = new SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault());
        String date = dateF.format(Calendar.getInstance().getTime());
        dateupdate.setText(date);
        Button updatebtn = (Button)dialogueView.findViewById(R.id.updatebtn);
        Button deletebtn = (Button)dialogueView.findViewById(R.id.deletebtn);
        final AlertDialog dialog = alertDialog.create();
        dialog.show();
        updatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String titleup = titleupdate.getText().toString().trim();
                String descup = descupdate.getText().toString().trim();
                String dateup = dateupdate.getText().toString().trim();
                if(TextUtils.isEmpty(titleup) || TextUtils.isEmpty(descup) || TextUtils.isEmpty(dateup)){
                    titleupdate.setError("Enter Title");
                    descupdate.setError("Enter description");
                    dateupdate.setError("Enter date");
                }
                else{
                    updateMethod(notesid, titleup, descup, dateup);
                    dialog.dismiss();
                }
            }
        });
        deletebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteMethod(notesid);
                dialog.dismiss();
            }
        });

    }

    public  void deleteMethod(String id){
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("notes").child(id);
        databaseReference.removeValue();
        Toast.makeText(this, "Data deleted", Toast.LENGTH_LONG).show();
    }

    public boolean updateMethod(String id, String title, String desc, String date){
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("notes").child(id);
        Notes notes = new Notes(id, title, desc, date);
        databaseReference.setValue(notes);
        Toast.makeText(this, "Data Updated", Toast.LENGTH_LONG).show();
        return true;
    }

    public void AddNotes(){
        titlesend = editText.getText().toString().trim();
        descsend = enterDesc.getText().toString().trim();
        datesend = editDate.getText().toString().trim();
        if(TextUtils.isEmpty(titlesend) || TextUtils.isEmpty(descsend) || TextUtils.isEmpty(datesend)){
            Toast.makeText(MainActivity.this,"Please enter correct data", Toast.LENGTH_LONG).show();
        }
        else{
            String id =  mDatabase.push().getKey();
            Notes notes = new Notes(id, titlesend, descsend, datesend);
            mDatabase.child(id).setValue(notes);
            Toast.makeText(MainActivity.this, "Data added", Toast.LENGTH_SHORT).show();
        }

    }


}