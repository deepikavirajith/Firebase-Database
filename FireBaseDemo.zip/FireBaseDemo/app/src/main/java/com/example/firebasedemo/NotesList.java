package com.example.firebasedemo;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class NotesList extends ArrayAdapter<Notes> {
    public Activity context;
    public List<Notes> notesList;

    public NotesList(Activity context, List<Notes> notesList){
        super(context, R.layout.list_layout, notesList);
        this.context = context;
        this.notesList = notesList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View list = inflater.inflate(R.layout.list_layout, null, true);
        TextView textViewTitle =(TextView)list.findViewById(R.id.textViewTitle);
        TextView textViewDesc =(TextView)list.findViewById(R.id.textViewDesc);
        TextView textViewDate =(TextView)list.findViewById(R.id.textViewDate);
        Notes notes = notesList.get(position);
            textViewTitle.setText(notes.getNotestitle());
            textViewDesc.setText(notes.getNotesdesc());
            textViewDate.setText(notes.getNotesdate());
            return list;

    }
}
