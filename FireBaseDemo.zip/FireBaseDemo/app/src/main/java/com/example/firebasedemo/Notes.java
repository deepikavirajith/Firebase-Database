package com.example.firebasedemo;

import java.lang.reflect.Constructor;

public class Notes  {
    String notesid;
    String notestitle;
    String notesdesc;
    String notesdate;


    public  Notes(){

    }

    public Notes(String notesid, String notestitle, String notesdesc, String notesdate) {
        this.notesid = notesid;
        this.notestitle = notestitle;
        this.notesdesc = notesdesc;
        this.notesdate = notesdate;
    }

    public String getNotesid() {
        return notesid;
    }

    public String getNotestitle() {
        return notestitle;
    }

    public String getNotesdesc() {
        return notesdesc;
    }

    public String getNotesdate() {
        return notesdate;
    }
}
